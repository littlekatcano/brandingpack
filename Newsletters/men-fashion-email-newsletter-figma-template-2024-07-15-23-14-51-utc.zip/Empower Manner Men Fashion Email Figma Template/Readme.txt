Men's Fashion Email Newsletter Figma Template

**Font used in the design:**

https://fonts.google.com/specimen/Bruno+Ace (For logo)
https://fonts.google.com/specimen/Koulen (logo and headline)
https://fonts.google.com/specimen/Quattrocento (Body/paragraph)


Design by BeadyLab
beadylab@gmail.com